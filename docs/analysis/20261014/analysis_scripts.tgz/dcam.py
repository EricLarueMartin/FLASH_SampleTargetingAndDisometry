import numpy as np, json, os, glob

CAP = "/home/codex/SynchronizedCameraDosimeter/dose_cam/captures/FLASH"
W, H = 1456, 1088
STRIDE = 2944            # bytes
ROWU16 = STRIDE // 2     # 1472 uint16 per row
FRAME_BYTES = 3203072

def frames(path):
    n = os.path.getsize(path) // FRAME_BYTES
    for i in range(n):
        a = np.fromfile(path, dtype='<u2', count=ROWU16*H, offset=i*FRAME_BYTES)
        a = a.reshape(H, ROWU16)[:, :W]
        a = (a >> 6).astype(np.uint16)       # 10-bit left aligned
        yield i, a[::-1, ::-1].copy()        # rotate 180 to match UI

def runs():
    out = []
    for j in sorted(glob.glob(os.path.join(CAP, "*.json"))):
        m = json.load(open(j))
        r = j[:-5] + ".raw"
        m['_raw'] = r
        m['_name'] = os.path.basename(j)[:-5]
        m['_nframes'] = os.path.getsize(r)//FRAME_BYTES
        out.append(m)
    return out

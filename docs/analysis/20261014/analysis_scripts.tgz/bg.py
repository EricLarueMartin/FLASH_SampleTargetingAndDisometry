import sys; sys.path.insert(0,'/home/codex/analysis_20261014')
import numpy as np
from dcam import runs, frames

bg_frames = []
for m in runs():
    if m['esp_delay_us'] == 100 and m['capture_mode'] == 'dosimetry':
        for i,a in frames(m['_raw']):
            bg_frames.append(a.astype(np.float32))
S = np.stack(bg_frames)
print("background stack:", S.shape)
bg_med = np.median(S, axis=0)
bg_mean = S.mean(axis=0)
np.save('/home/codex/analysis_20261014/bg_med.npy', bg_med)
np.save('/home/codex/analysis_20261014/bg_mean.npy', bg_mean)
print("bg_med  min/med/max  %.2f %.2f %.2f" % (bg_med.min(), np.median(bg_med), bg_med.max()))
print("bg_mean min/med/max  %.3f %.3f %.3f" % (bg_mean.min(), np.median(bg_mean), bg_mean.max()))
# structure after removing pedestal: smooth heavily
from scipy.ndimage import uniform_filter
sm = uniform_filter(bg_mean, 33)
print("smoothed bg_mean  min %.3f  p1 %.3f  p50 %.3f  p99 %.3f  max %.3f" % (
    sm.min(), np.percentile(sm,1), np.percentile(sm,50), np.percentile(sm,99), sm.max()))
np.save('/home/codex/analysis_20261014/bg_mean_smooth.npy', sm)
# also the targeting frame (1000us gate) - better ambient illumination
for m in runs():
    if m['capture_mode']=='targeting':
        for i,a in frames(m['_raw']):
            t = a.astype(np.float32)
            np.save('/home/codex/analysis_20261014/targeting.npy', t)
            ts = uniform_filter(t, 33)
            print("targeting smoothed min %.2f p1 %.2f p50 %.2f p99 %.2f max %.2f" % (
                ts.min(), np.percentile(ts,1), np.percentile(ts,50), np.percentile(ts,99), ts.max()))

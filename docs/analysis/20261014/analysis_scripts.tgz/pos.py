import sys; sys.path.insert(0,'/home/codex/analysis_20261014')
import numpy as np, json, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
from scipy.ndimage import uniform_filter, median_filter
from dcam import runs, frames

OUT='/home/codex/analysis_20261014/out/'
fits={ (r['run'],r['frame']):r for r in json.load(open('/home/codex/analysis_20261014/fits.json')) }

def despike(a, thr=40):
    m=median_filter(a,3); bad=(a-m)>thr; o=a.copy(); o[bad]=m[bad]; return o

def gauss2d(p,X,Y):
    A,x0,y0,sx,sy,th,off=p
    c,s=np.cos(th),np.sin(th)
    xr=(X-x0)*c+(Y-y0)*s; yr=-(X-x0)*s+(Y-y0)*c
    return A*np.exp(-0.5*((xr/sx)**2+(yr/sy)**2))

Y,X=np.mgrid[0:1088,0:1456]

# the six plate shots: 2 pre-fix (delay100) + 4 post-fix (delay200)
sel=[]
for m in runs():
    if not m['_name'].startswith('PolyAlDosCal'): continue
    if m['capture_mode']=='targeting': continue
    for i,a in frames(m['_raw']):
        sel.append((m,i,a.astype(np.float32)))

labels={ (5,0):'pre-fix A  (100us)', (5,1):'pre-fix B  (100us)',
         (6,0):'post-fix #1', (6,1):'post-fix #2', (6,2):'post-fix #3', (6,3):'post-fix #4' }

proc=[]
for m,i,a in sel:
    runno=int(m['_name'].split('_')[-1])
    f=despike(a)
    ped=np.median(f)
    r=fits[(m['_name'],i)]
    model=gauss2d([r['A'],r['x0'],r['y0'],r['sx'],r['sy'],np.radians(r['theta_deg']),0.0],X,Y)
    res=f-ped-model                      # peak removed, pedestal removed
    sm=uniform_filter(res,21)
    proc.append(dict(m=m,i=i,runno=runno,sm=sm,r=r,lab=labels.get((runno,i),'%s f%d'%(m['_name'],i))))

# common stretch across the six, robust
allv=np.concatenate([p['sm'][40:-40,40:-40].ravel()[::7] for p in proc])
v1,v2=np.percentile(allv,0.5),np.percentile(allv,99.5)
print('stretch %.3f %.3f'%(v1,v2))

fig,axs=plt.subplots(2,3,figsize=(22,12))
for ax,p in zip(axs.ravel(),proc):
    im=ax.imshow(p['sm'],cmap='magma',vmin=v1,vmax=v2)
    r=p['r']
    for n,ls in ((2,'-'),(4,'--')):
        ax.add_patch(Ellipse((r['x0'],r['y0']),n*r['sx'],n*r['sy'],angle=r['theta_deg'],
                     fill=False,ec='cyan',lw=1.6,ls=ls))
    ax.plot(r['x0'],r['y0'],'c+',ms=12)
    ax.set_title('%s   peak removed (A=%.1f DN)'%(p['lab'],r['A']),fontsize=11)
    plt.colorbar(im,ax=ax,fraction=0.035,label='DN')
plt.suptitle('PolyAl plate shots - fitted Gaussian subtracted, background smoothed 21px; cyan = 2 sigma / 4 sigma of fitted spot',fontsize=12)
plt.tight_layout(); plt.savefig(OUT+'positions.png',dpi=65); plt.close()

# difference maps relative to the mean of the six -> highlights what moved
stack=np.stack([p['sm'] for p in proc]); ref=stack.mean(0)
fig,axs=plt.subplots(2,3,figsize=(22,12))
d=stack-ref
w=np.percentile(np.abs(d[:,40:-40,40:-40]),99.0)
for ax,p,dd in zip(axs.ravel(),proc,d):
    im=ax.imshow(dd,cmap='coolwarm',vmin=-w,vmax=w)
    r=p['r']
    ax.add_patch(Ellipse((r['x0'],r['y0']),2*r['sx'],2*r['sy'],angle=r['theta_deg'],fill=False,ec='k',lw=1.6))
    ax.set_title('%s  minus mean-of-six'%p['lab'],fontsize=11)
    plt.colorbar(im,ax=ax,fraction=0.035,label='DN')
plt.suptitle('Difference from the mean of the six - bright/dark pairs show where the poly/Al holder frame moved',fontsize=12)
plt.tight_layout(); plt.savefig(OUT+'positions_diff.png',dpi=65); plt.close()
print('done')

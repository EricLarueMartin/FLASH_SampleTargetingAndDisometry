import csv
exec(open('test_beamfit.py').read().split("print('%-6s")[0])
labels=['B1 (expected)','A1 (expected)','A2 (expected)','A3 (expected)']
cols=['frame','expected_position','background','amplitude_dn','center_x','center_y','sigma_x','sigma_y','fwhm_x','fwhm_y','theta_deg','offset_dn','integrated_dn_fit','integrated_dn_sum','chi2_reduced','r_squared','rms_residual_dn','noise_sigma_dn','despiked_px','saturated_px','roi']
with open('out/crosscal_fits_PolyAlDosCal_000006.csv','w',newline='') as fh:
    w=csv.writer(fh); w.writerow(cols)
    for mode,bgp in (('baseline',''),('file',BG),('none','')):
        for i in range(4):
            r=beam_fit.analyze(cam,source='file',path=GOOD,frame=i,background=mode,bg_path=bgp,bg_frames=0)
            f=r['fit']
            w.writerow([i+1,labels[i],mode+(' (Alanine_000002, 34-frame mean)' if mode=='file' else '')]+
              ['%.4f'%f[k] for k in cols[3:18]]+[r['despike']['pixels_replaced'],r['saturated_pixels'],
              '%dx%d@(%d,%d)'%(r['roi']['w'],r['roi']['h'],r['roi']['x'],r['roi']['y'])])
print(open('out/crosscal_fits_PolyAlDosCal_000006.csv').read())

import sys, os, numpy as np
sys.path.insert(0, '/home/codex/SynchronizedCameraDosimeter/dose_cam')
ROOT = '/home/codex/SynchronizedCameraDosimeter/dose_cam/captures'
W,H,STRIDE = 1456,1088,2944
FB = STRIDE*H

class StubCam:
    """Only the two hooks beam_fit uses, so no GPIO is touched."""
    store = {}
    def _path_for_relative(self, rel):
        parts=[p for p in (rel or '').replace('\\','/').split('/') if p and p not in ('.','..')]
        p=os.path.abspath(os.path.join(ROOT,*parts))
        if p!=ROOT and not p.startswith(ROOT+os.sep): raise ValueError('outside')
        return p
    def _decode_raw_stream_frame(self, frame):
        row=np.frombuffer(frame,dtype='<u2').reshape((H,STRIDE//2))
        d=row[:,:W].astype(np.uint16,copy=False)
        if d.max()>1023: d=d>>6
        return np.clip(d,0,1023).astype(np.uint16)


# beam_fit imports camera_core inside functions for constants; provide a stub module
import types
cc = types.ModuleType('camera_core')
cc.RAW_FRAME_BYTES = FB; cc.WIDTH=W; cc.HEIGHT=H; cc.RAW_STRIDE_BYTES=STRIDE
cc.RAW_MIN_DN=0; cc.RAW_MAX_DN=1023; cc.RAW_CONTAINER_SHIFT=6
sys.modules['camera_core']=cc

import beam_fit
cam=StubCam()
GOOD='FLASH/PolyAlDosCal_20261013_161112_732305_000006.raw'
BG  ='FLASH/Alanine_20261013_145026_730724_000002.raw'

print('%-6s %-10s %8s %8s %8s %7s %7s %8s %8s %8s %7s'%(
 'frame','bg','A_DN','x0','y0','sx','sy','theta','integ','R2','chi2r'))
for mode,bgp in (('none',''),('baseline',''),('file',BG)):
    for i in range(4):
        r=beam_fit.analyze(cam, source='file', path=GOOD, frame=i,
                           background=mode, bg_path=bgp, bg_frames=10)
        f=r['fit']
        print('%-6d %-10s %8.2f %8.1f %8.1f %7.2f %7.2f %8.2f %8.4g %8.4f %7.2f'%(
          i,mode,f['amplitude_dn'],f['center_x'],f['center_y'],f['sigma_x'],f['sigma_y'],
          f['theta_deg'],f['integrated_dn_fit'],f['r_squared'],f['chi2_reduced']))
    print('-'*100)
r=beam_fit.analyze(cam,source='file',path=GOOD,frame=0,background='file',bg_path=BG,bg_frames=10)
print('saturated',r['saturated_pixels'],'spikes',r['despike']['pixels_replaced'],
      'roi',r['roi'],'cal',r['calibration'],'space',r['coordinate_space'])

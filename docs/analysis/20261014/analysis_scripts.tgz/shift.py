import sys; sys.path.insert(0,'/home/codex/analysis_20261014')
import numpy as np, json, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
from scipy.ndimage import uniform_filter, median_filter, gaussian_filter
from dcam import runs, frames
OUT='/home/codex/analysis_20261014/out/'
fits={(r['run'],r['frame']):r for r in json.load(open('/home/codex/analysis_20261014/fits.json'))}
def despike(a,t=40):
    m=median_filter(a,3); b=(a-m)>t; o=a.copy(); o[b]=m[b]; return o
Y,X=np.mgrid[0:1088,0:1456].astype(np.float32)
def ell_mask(r,n):
    th=np.radians(r['theta_deg']); c,s=np.cos(th),np.sin(th)
    xr=(X-r['x0'])*c+(Y-r['y0'])*s; yr=-(X-r['x0'])*s+(Y-r['y0'])*c
    return (xr/r['sx'])**2+(yr/r['sy'])**2 <= n*n
good=[m for m in runs() if m['esp_delay_us']==200][0]
pre=[m for m in runs() if m['_name'].endswith('000005')][0]
items=[]
for m,lab in ((pre,['pre-fix 1 (100us)','pre-fix 2 (100us)']),(good,['#1 (B1?)','#2 (A1?)','#3 (A2?)','#4 (A3?)'])):
    for i,a in frames(m['_raw']):
        f=despike(a.astype(np.float32)); ped=np.median(f)
        r=fits[(m['_name'],i)]
        if m is good:
            sup=f.copy(); sup[ell_mask(r,3.5)]=np.nan
        else:
            sup=f.copy()
        # fill NaN with local median for smoothing
        nan=np.isnan(sup); fill=sup.copy(); fill[nan]=ped
        sm=gaussian_filter(fill-ped,6)
        items.append(dict(lab=lab[i],r=r if m is good else fits[(good['_name'],0)],sm=sm,nan=nan,good=(m is good)))

# hard-stretched peak-suppressed view per shot, with ellipse of the fitted spot
fig,axs=plt.subplots(2,3,figsize=(21,11.5))
for ax,it in zip(axs.ravel(),items):
    v=it['sm'][30:-30,30:-30]
    lo,hi=np.percentile(v,1),np.percentile(v,99.3)
    show=it['sm'].copy(); show[it['nan']]=np.nan
    ax.imshow(show,cmap='gray',vmin=lo,vmax=hi)
    r=it['r']
    for n,ls in ((1,'-'),(2,'-'),(3.5,'--')):
        ax.add_patch(Ellipse((r['x0'],r['y0']),2*n*r['sx'],2*n*r['sy'],angle=r['theta_deg'],fill=False,ec='cyan' if it['good'] else 'orange',lw=1.4,ls=ls))
    ax.set_title(it['lab']+('  - peak blanked to 3.5 sigma' if it['good'] else '  - no signal; ellipse = beam position from post-fix fit'),fontsize=11)
    ax.set_xlim(250,1350); ax.set_ylim(950,50)
plt.suptitle('Peak-suppressed background, Gaussian-smoothed 6 px, crop x 250-1350 / y 50-950 (display orientation)',fontsize=12)
plt.tight_layout(); plt.savefig(OUT+'positions_suppressed.png',dpi=62); plt.close()

# consecutive differences, mask spot region for all
pairs=[(0,1),(2,3),(3,4),(4,5)]
fig,axs=plt.subplots(1,4,figsize=(26,6.6))
mask=ell_mask(items[2]['r'],4.5)
res=[]
for ax,(a,b) in zip(axs,pairs):
    d=items[b]['sm']-items[a]['sm']; d[mask]=0
    w=np.percentile(np.abs(d[30:-30,30:-30]),99.3)
    ax.imshow(d,cmap='coolwarm',vmin=-w,vmax=w); ax.set_xlim(250,1350); ax.set_ylim(950,50)
    ax.set_title('%s  minus  %s'%(items[b]['lab'],items[a]['lab']),fontsize=11)
    r=items[2]['r']; ax.add_patch(Ellipse((r['x0'],r['y0']),9*r['sx'],9*r['sy'],angle=r['theta_deg'],fill=False,ec='k',lw=1))
plt.suptitle('Consecutive differences (red = brighter in the later shot). Spot region zeroed.',fontsize=12)
plt.tight_layout(); plt.savefig(OUT+'positions_steps.png',dpi=62); plt.close()

# shift estimate: phase correlation of high-passed, spot-masked structure in a central crop
def hp(sm):
    h=sm-gaussian_filter(sm,40); h=h.copy(); h[mask]=0; return h[150:900,350:1300]
def xcorr_shift(a,b):
    A=np.fft.fft2(a); B=np.fft.fft2(b)
    R=A*np.conj(B); R/=np.abs(R)+1e-9
    c=np.real(np.fft.ifft2(R)); c=np.fft.fftshift(c)
    iy,ix=np.unravel_index(np.argmax(c),c.shape)
    peak=c[iy,ix]; bg=np.std(c)
    return ix-c.shape[1]//2, iy-c.shape[0]//2, peak/bg
print('shift of later shot relative to earlier (dx, dy px, display coords), significance = peak/std of correlation surface')
for a,b in pairs:
    dx,dy,sig=xcorr_shift(hp(items[b]['sm']),hp(items[a]['sm']))
    print('  %-20s -> %-20s dx=%5d dy=%5d  sig=%5.1f'%(items[a]['lab'],items[b]['lab'],dx,dy,sig))
print('done')

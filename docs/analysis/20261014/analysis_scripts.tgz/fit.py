import sys; sys.path.insert(0,'/home/codex/analysis_20261014')
import numpy as np, json
from scipy.ndimage import uniform_filter, median_filter
from scipy.optimize import least_squares
from dcam import runs, frames

def despike(a, thr=40):
    m = median_filter(a, 3)
    bad = (a - m) > thr
    out = a.copy(); out[bad] = m[bad]
    return out, int(bad.sum())

def gauss2d(p, X, Y):
    A, x0, y0, sx, sy, th, off = p
    c, s = np.cos(th), np.sin(th)
    xr = (X-x0)*c + (Y-y0)*s
    yr = -(X-x0)*s + (Y-y0)*c
    return off + A*np.exp(-0.5*((xr/sx)**2 + (yr/sy)**2))

def fit_spot(img, half=260):
    sm = uniform_filter(img, 25)
    y0, x0 = np.unravel_index(np.argmax(sm), sm.shape)
    y1,y2 = max(0,y0-half), min(img.shape[0], y0+half)
    x1,x2 = max(0,x0-half), min(img.shape[1], x0+half)
    sub = img[y1:y2, x1:x2]
    Y, X = np.mgrid[y1:y2, x1:x2]
    A0 = sm[y0,x0] - np.median(sub)
    p0 = [A0, float(x0), float(y0), 60., 60., 0.0, float(np.median(sub))]
    lo = [0, x1, y1, 2, 2, -np.pi/2, -50]
    hi = [4000, x2, y2, 400, 400, np.pi/2, 200]
    r = least_squares(lambda p: (gauss2d(p, X, Y)-sub).ravel(), p0, bounds=(lo,hi), loss='soft_l1', f_scale=5.0)
    p = r.x
    model = gauss2d(p, X, Y)
    resid = sub - model
    ss_res = float((resid**2).sum()); ss_tot = float(((sub-sub.mean())**2).sum())
    r2 = 1 - ss_res/ss_tot
    rms = float(np.sqrt((resid**2).mean()))
    # integrated signal over window, background-subtracted by fitted offset
    integ = float((sub - p[6]).sum())
    return dict(A=float(p[0]), x0=float(p[1]), y0=float(p[2]),
                sx=float(abs(p[3])), sy=float(abs(p[4])), theta_deg=float(np.degrees(p[5])),
                off=float(p[6]), r2=r2, rms=rms, integ_DN=integ,
                fwhm_x=float(2.3548*abs(p[3])), fwhm_y=float(2.3548*abs(p[4])),
                win=[int(x1),int(x2),int(y1),int(y2)])

bgm = np.load('/home/codex/analysis_20261014/bg_med.npy')
res = []
for m in runs():
    if m['capture_mode']=='targeting': continue
    for i,a in frames(m['_raw']):
        f = a.astype(np.float32)
        f, nspike = despike(f)
        d = f - bgm
        r = fit_spot(d)
        r.update(run=m['_name'], frame=i, delay=m['esp_delay_us'], width=m['esp_width_us'], spikes=nspike)
        res.append(r)
json.dump(res, open('/home/codex/analysis_20261014/fits.json','w'), indent=1)

print("%-38s %2s %4s %7s %8s %8s %6s %6s %7s %7s %6s" % ("run","f","dly","A_DN","x0","y0","sx","sy","th_deg","integ","R2"))
for r in res:
    print("%-38s %2d %4d %7.1f %8.1f %8.1f %6.1f %6.1f %7.1f %7.3g %6.3f" % (
        r['run'][:38], r['frame'], r['delay'], r['A'], r['x0'], r['y0'], r['sx'], r['sy'], r['theta_deg'], r['integ_DN'], r['r2']))
